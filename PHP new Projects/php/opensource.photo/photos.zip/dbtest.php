<?php

	$host="localhost";
        $user="initedit_iea";
        $pass="@Android1";
        $db="initedit_ie";
        $con=mysqli_connect($host,$user,$pass,$db);
        if(!$con){
          echo mysqli_error($con);
          exit();
        }

?>
