<?php
include_once "php/class/query.php";
include_once "php/session/session_start.php";
$IMAGICK_LOADED = false;
if (extension_loaded("imagick")) {
    $IMAGICK_LOADED = true;
}
$image = $_POST['img'];
$screenWidth = $_POST['width'] * 0.745;
$screenHeight = $_POST['height'];
$PAGE = $_POST['page'];
$SEARCH = $_POST['search'];
$PAGE_ARRAY = explode("/", $PAGE);
$FIRST_PAGE = $PAGE_ARRAY[1];
list($width, $height, $type, $attr) = getimagesize("./uploads/original/$image");
$newWidth = $width;
$newHeight = $height;
$fact = 0.95;
while ($newHeight > $screenHeight || $newWidth > $screenWidth) {
    $newWidth = $newWidth * $fact;
    $newHeight = $newHeight * $fact;
}
$CURR_USERID = (isset($_SESSION['userid'])) ? $_SESSION['userid'] : -10;
$title = QUERY::c("select title from images where img='{$image}'");
$imageid = QUERY::c("select imgid from images where img='{$image}'");
$likeCount = QUERY::c("select count(*) from imagelike where imgid=$imageid");
$favCount = QUERY::c("select count(*) from imagefav where imgid=$imageid");
$isLiked = QUERY::c("select count(*) from imagelike where imgid=$imageid && userid=$CURR_USERID");
$isFav = QUERY::c("select count(*) from imagefav where imgid=$imageid && userid=$CURR_USERID");
$viewCount = QUERY::c("select view from images where imgid=$imageid");
//$nextImage = QUERY::c("select img from images where imgid=(select imgid+1 from images where img='{$image}')");
//$previousImage = QUERY::c("select img from images where  imgid=(select imgid-1 from images where img='{$image}')");
if ($FIRST_PAGE == "") {
    $nextImage = QUERY::c("select img from images where imgid>$imageid and enable=0 order by time desc limit 0,1");
    $previousImage = QUERY::c("select img from images where  imgid<$imageid and enable=0  order by time desc limit 0,1");
    if ($previousImage == "") {
        $previousImage = QUERY::c("select img from images where enable=0 order by time desc limit 1");
    }
    if ($nextImage == "") {
        $nextImage = QUERY::c("select img from images where enable=0 order by time asc limit 1");
    }
} else if ($FIRST_PAGE == "hash") {
    $HASH = $PAGE_ARRAY[2];
    $nextImage = QUERY::c("select img from images where imgid>$imageid and enable=0 and title like '#{$HASH}' order by time desc limit 0,1");
    $previousImage = QUERY::c("select img from images where  imgid<$imageid and enable=0 and title like '#{$HASH}'  order by time desc limit 0,1");

    if ($previousImage == "") {
        $previousImage = QUERY::c("select img from images where enable=0 and title like '#{$HASH}' order by time desc limit 1");
    }
    if ($nextImage == "") {
        $nextImage = QUERY::c("select img from images where enable=0 and title like '#{$HASH}' order by time asc limit 1");
    }
} else if ($FIRST_PAGE == "search") {
    $SEARCH_QUERY = substr($SEARCH, 1);
    parse_str($SEARCH_QUERY, $output);
    $searchFor = $output['searchfor'];
    $nextImage = QUERY::c("select img from images where imgid>$imageid and enable=0 and title like '%$searchFor%' order by time desc limit 0,1");
    $previousImage = QUERY::c("select img from images where  imgid<$imageid and enable=0 and title like '%$searchFor%'  order by time desc limit 0,1");
    if ($previousImage == "") {
        $previousImage = QUERY::c("select img from images where enable=0 and title like '%$searchFor%' order by time desc limit 1");
    }
    if ($nextImage == "") {
        $nextImage = QUERY::c("select img from images where enable=0 and title like '%$searchFor%' order by time asc limit 1");
    }

} else if (QUERY::c("select count(*) from usersignup where username='{$FIRST_PAGE}'") == "1") {
    $PROFILE_SUB = (isset($PAGE_ARRAY[2]))?$PAGE_ARRAY[2]:"";
    $PROFILE_USERID = QUERY::c("select userid from usersignup where username='{$FIRST_PAGE}'");
    if ($PROFILE_SUB == "") {
        $nextImage = QUERY::c("select img from images where imgid>$imageid and enable=0 and userid=$PROFILE_USERID order by time desc limit 0,1");
        $previousImage = QUERY::c("select img from images where  imgid<$imageid and enable=0 and userid=$PROFILE_USERID  order by time desc limit 0,1");

        if ($previousImage == "") {
            $previousImage = QUERY::c("select img from images where enable=0 and userid=$PROFILE_USERID order by time desc limit 1");
        }
        if ($nextImage == "") {
            $nextImage = QUERY::c("select img from images where enable=0 and userid=$PROFILE_USERID order by time asc limit 1");
        }
    } else if ($PROFILE_SUB == "likes") {
        $nextImage = QUERY::c("select img from images where imgid>$imageid and enable=0 and imgid IN (select imgid from imagelike where userid=$PROFILE_USERID) order by time desc limit 0,1");
        $previousImage = QUERY::c("select img from images where  imgid<$imageid and enable=0 and imgid IN (select imgid from imagelike where userid=$PROFILE_USERID)  order by time desc limit 0,1");
        if ($previousImage == "") {
            $previousImage = QUERY::c("select img from images where enable=0 and imgid IN (select imgid from imagelike where userid=$PROFILE_USERID) order by time desc limit 1");
        }
        if ($nextImage == "") {
            $nextImage = QUERY::c("select img from images where enable=0 and imgid IN (select imgid from imagelike where userid=$PROFILE_USERID) order by time asc limit 1");
        }
    } else if ($PROFILE_SUB == "favourites") {
        $nextImage = QUERY::c("select img from images where imgid>$imageid and enable=0 and imgid IN (select imgid from imagefav where userid=$PROFILE_USERID) order by time desc limit 0,1");
        $previousImage = QUERY::c("select img from images where  imgid<$imageid and enable=0 and imgid IN (select imgid from imagefav where userid=$PROFILE_USERID)  order by time desc limit 0,1");
        if ($previousImage == "") {
            $previousImage = QUERY::c("select img from images where enable=0 and imgid IN (select imgid from imagefav where userid=$PROFILE_USERID) order by time desc limit 1");
        }
        if ($nextImage == "") {
            $nextImage = QUERY::c("select img from images where enable=0 and imgid IN (select imgid from imagefav where userid=$PROFILE_USERID) order by time asc limit 1");
        }
    }
}
//if ($previousImage == "") {
//    $previousImage = QUERY::c("select img from images where enable=0 order by time desc limit 1");
//}
//if ($nextImage == "") {
//    $nextImage = QUERY::c("select img from images where enable=0 order by time asc limit 1");
//}
$imgUserid = QUERY::c("select userid from images where img='{$image}'");

$titleArray = preg_split("/#/", $title);
$val = '';
if (count($titleArray) > 1) {
    foreach ($titleArray as $valueArray) {
        if ($valueArray != "")
            $val .= substr_replace($valueArray, "<a href='/hash/$valueArray' class='link'>#$valueArray</a>", null);
    }
} else {
    $val = $title;
}
if ($val == "") {
    $val = "untitled";
}
QUERY::query("update images set view = view + 1 where img='{$image}'");

$newWidth = (isset($_SESSION['ismobile'])) ? "100%" : $newWidth;
?>

<!--
<div class="fullImageTitle" style="width:100%;padding:5px 0px;opacity:0.9;background:#FFF;color:#000;position: fixed;min-height: 25px;padding: 5px;"><?php
echo $val;;
?></div>
-->
<div class="leftImageBoxContainer fl" style="position: relative;background:#000;">
    <div class="fullImageNavigateLeft" onclick="loadFullImage('<?php echo $nextImage; ?>')"
         style="position: absolute;z-index: 1;color: #FFF; background: rgba(80,80,80,0.6);    border: 2px solid rgba(120,120,120,0.9);">
        &lt;</div>
    <div class="fullImageNavigateRight" onclick="loadFullImage('<?php echo $previousImage; ?>')"
         style="position: absolute;z-index: 1;color: #FFF;background: rgba(80,80,80,0.6);border: 2px solid rgba(120,120,120,0.9);">
        &gt;</div>
    <div style="margin:0 auto;width:<?php echo $newWidth; ?>px;height: 100%;position: relative;">

        <a href="/detail/photo/<?php echo $image; ?>">
            <img src="/uploads/compressed/<?php echo $image; ?>" width="<?php echo $newWidth; ?>"
                 height="<?php echo $newHeight; ?>"
                 style="position:absolute;top:50%;margin-top:-<?php echo $newHeight / 2; ?>px;"/>
        </a>
    </div>

    <?php if (QUERY::c("select username from usersignup where userid=$imgUserid") == @$_SESSION['username']) { ?>
        <div style="position: absolute;bottom:0px;padding: 10px;right: 0px;" class="photoOptions">
            <ul class="hl" style="color:#333;background: #DDD;overflow: hidden;padding:5px 15px;">
                <li onclick="deleteImages('<?php echo $image; ?>')">Delete</li>
            </ul>
        </div>
    <?php } ?>
</div>
<?php if (isset($_SESSION['ismobile'])) {
    ?>
    <div class="rightImageBoxContainer fl">
        <div class="rightImageBox">
            Uploaded By : <?php echo QUERY::c("select username from usersignup where userid=$imgUserid"); ?>
        </div>
    </div>

    <?php
    return;
}
?>
<div class="rightImageBoxContainer fl"
     style="text-align: initial;border: none;width: 23%;padding: 1%;padding-bottom: 0vh;padding-top: 2vh;">
    <div class="rightImageBox" style="height: 98vh;overflow-y: scroll;color:#999;">
        <div style="padding-bottom: 10px;margin-bottom: 10px;min-height: 75px;border-bottom: 1px solid #999;">
            <ul class="hl">
                <li>
                    <img
                        src="/uploads/profile/thumb/<?php echo QUERY::c("select img from usersignup where userid=$imgUserid"); ?>"
                        height="75" width="75"/>
                </li>
                <li style="padding-left: 10px;">
                    <span><a href="/<?php echo QUERY::c("select username from usersignup where userid=$imgUserid"); ?>"
                             class="link"><?php echo QUERY::c("select username from usersignup where userid=$imgUserid"); ?></a></span>
                </li>
            </ul>
        </div>
        <div class="clearFix"></div>
        <div style="    word-break: break-all;margin-bottom: 10px;">
            <strong><?php echo $val; ?></strong>
        </div>
        <p></p>
        <div>
            <ul class="hl">
                <li style="cursor: pointer;color:#333;background: #DDD;overflow: hidden;padding:5px 15px;<?php echo ($isLiked == 0) ? "display:block;" : "display:none;" ?>"
                    id="fullLikeText" onclick="likeImages('<?php echo $image; ?>')">Like
                </li>
                <li style="cursor: pointer;color:#333;background: #DDD;overflow: hidden;padding:5px 15px;background: #5586FF; color: #FFF;<?php echo ($isLiked == 0) ? "display:none;" : "display:block;" ?>"
                    id="fullDislikeText" onclick="dislikeImages('<?php echo $image; ?>')">Like
                </li>
                <li style="color:#333;background: #DDD;overflow: hidden;padding:5px 10px;background: #5586FF; color: #FFF;margin-right: 20px; "
                    id="fullLikeCount"><?php echo $likeCount; ?></li>
                <li style="cursor: pointer;color:#333;background: #DDD;overflow: hidden;padding:5px 15px;<?php echo ($isFav == 0) ? "display:block;" : "display:none;" ?>"
                    id="fullFavText" onclick="favImages('<?php echo $image; ?>')">Favourite
                </li>
                <li style="cursor: pointer;color:#333;background: #DDD;overflow: hidden;padding:5px 15px;background: #FF5588; color: #FFF;<?php echo ($isFav == 0) ? "display:none;" : "display:block;" ?>"
                    id="fullUnfavText" onclick="unfavImages('<?php echo $image; ?>')">Favourite
                </li>
                <li style="color:#333;background: #DDD;overflow: hidden;padding:5px 10px;background: #FF5588; color: #FFF;margin-right: 20px; "
                    id="fullFavCount"><?php echo $favCount; ?></li>
            </ul>
        </div>
        <div class="clearFix"></div>
        <p></p>
        <div>
            <ul class="hl">
                <li style="cursor: pointer;color:#333;background: #DDD;overflow: hidden;padding:5px 15px;">View</li>
                <li style="color:#333;background: #DDD;overflow: hidden;padding:5px 10px;background: rgba(50,200,80,0.9);; color: #FFF;margin-right: 20px; "><?php echo $viewCount; ?></li>
            </ul>
        </div>
        <div class="clearFix"></div>
        <p></p>
        <?php if (QUERY::c("select username from usersignup where userid=$imgUserid") == @$_SESSION['username']) { ?>
            <div style="min-height: 75px;border-top: 1px solid #999;">
                <h4 style="text-align: left;margin-top: 5px;">Privacy</h4>
                <select id="imageprivacy" class="select selectPrivacy" onchange="setPrivacy('<?php echo $image; ?>')">
                    <option>Public</option>
                    <option <?php echo (QUERY::c("select privacy from images where img='{$image}'") == "0") ? "" : "selected"; ?>>
                        Private
                    </option>
                </select>
            </div>
            <p></p>
            <div style="text-align: left;margin-bottom: 10px;"><input type="button" style="width:100%;"
                                                                      value='Set As Cover'
                                                                      onclick="setAsCover('<?php echo $image; ?>')"/>
            </div>
        <?php } ?>
        <div style="text-align: left;"><a href="/detail/photo/<?php echo $image; ?>"><input type="button"
                                                                                            style="width:100%;"
                                                                                            value='View Full Image'/></a>
        </div>

        <table style="color:#999;text-align: left;margin-top: 30px;">
            <tr>
                <th style="min-width: 100px;">Name</th>
                <th>Description</th>
            </tr>
            <!--<tr><td>Uploaded By </td> <td><?php echo QUERY::c("select username from usersignup where userid=$imgUserid"); ?></td></tr>-->
            <tr>
                <td>Album</td>
                <td><?php echo QUERY::c("select album from album where albumid=(select albumid from images where img='{$image}')"); ?></td>
            </tr>
            <?php
            if ($IMAGICK_LOADED) {
                $imagicObject = new Imagick("./uploads/original/$image");


                echo "<tr><td>Image Type</td> <td>" . $imagicObject->getImageMimeType() . "</td></tr>";
                echo "<tr><td>Width</td> <td>" . $imagicObject->getImageGeometry()['width'] . "</td></tr>";
                echo "<tr><td>Height</td> <td>" . $imagicObject->getImageGeometry()['height'] . "</td></tr>";
                echo "<tr><td>Size</td> <td>" . ceil($imagicObject->getImageLength() / 1024) . " KB</td></tr>";


                $imageInfo = $imagicObject->getImageProperties();

//print_f($imageInfo);
                foreach ($imageInfo as $name => $property) {
                    if ($name == "exif:ApertureValue") {
                        echo "<tr><td>Aperture</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Make") {
                        echo "<tr><td>Company</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Model") {
                        echo "<tr><td>Camera</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:ShutterSpeedValue") {
                        echo "<tr><td>Shutter Speed Value</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:ExposureTime") {
                        echo "<tr><td>Exposure Time</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Software") {
                        echo "<tr><td>Software</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:FocalLength") {
                        echo "<tr><td>Focal Length</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:FNumber") {
                        echo "<tr><td>FNumber</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Flash") {
                        echo "<tr><td>Flash</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:MaxApertureValue") {
                        echo "<tr><td>Max Aperture Value</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:ISOSpeedRatings") {
                        echo "<tr><td>ISO Speed Rating</td> <td>{$property}</td></tr>";
                    }
                }
                $imagicObject->clear();
            }
            ?>
        </table>


    </div>

</div>