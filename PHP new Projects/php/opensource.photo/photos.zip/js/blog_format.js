
    var ele = _("inputContent");
    var ele_none = _("inputContentDummy");
    function updateOutput() {
        content = $("#inputContent").val();

        content = content.replace(/</g, "&lt;");
        content = content.replace(/>/g, "&gt;");
            //&#42; for *
            //&#126; for ~
            //&#93; ]
            //&#93; [
        content = content.replace(/ \*\* /g, "&nbsp;&#42;&#42;&nbsp;");
    
        content = content.replace(/ \* /g, "&nbsp;&#42;&nbsp;");
        
        content = content.replace(/ ~ /g, "&nbsp;&#126;&nbsp;");
        
        content = content.replace(/ \[\[ /g, "&nbsp;&#91;&#91;&nbsp;");
        content = content.replace(/ \]\] /g, "&nbsp;&#93;&#93;&nbsp;");
     
        content = content.replace(/ \[ /g, "&nbsp;&#91;&nbsp;");
        content = content.replace(/ \] /g, "&nbsp;&#93;&nbsp;");
        
        content = content.replace(/ \{{{{ /g, "&nbsp;&#123;&#123;&#123;&#123;&nbsp;");
        content = content.replace(/ \}}}} /g, "&nbsp;&#125;&#125;&#125;&#125;&nbsp;");
        
        content = content.replace(/ \{{{ /g, "&nbsp;&#123;&#123;&#123;&nbsp;");
        content = content.replace(/ \}}} /g, "&nbsp;&#125;&#125;&#125;&nbsp;");
        
        content = content.replace(/ \{{ /g, "&nbsp;&#123;&#123;&nbsp;");
        content = content.replace(/ \}} /g, "&nbsp;&#125;&#125;&nbsp;");
        
        content = content.replace(/ ## /g, "&nbsp;&#35;&#35;&nbsp;");
        
        content = content.replace(/\n\-\-\-\-\n/g, "<hr/>");
        var res = content.match(/\*\*[a-zA-Z0-9<>'"\/:\.\s\t\n<>=]+\*\*/g);

        if (res != null) {
            e("Bold : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("**");
                index_2 = res[i].indexOf("**", index_1 + 2);
                sub_string = res[i].substring(index_1 + 2, index_2);
                content = content.replace(res[i], "<b>" + sub_string + "</b>");
                e(""+res[i]);
            }
        }
        var res = content.match(/\*[a-zA-Z0-9<>'"\/:\.\s\t\n<>=]+\*/g);

        if (res != null) {
            e("Italic : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("*");
                index_2 = res[i].indexOf("*", index_1 + 1);
                sub_string = res[i].substring(index_1 + 1, index_2);
                content = content.replace(res[i], "<i>" + sub_string + "</i>");
                e(""+res[i]);
            }
        }

        var res = content.match(/~[a-zA-Z0-9<>'"\/:\.\s\t\n<>=]+~/g);

        if (res != null) {
            e("Underline : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("~");
                index_2 = res[i].indexOf("~", index_1 + 1);
                sub_string = res[i].substring(index_1 + 1, index_2);
                content = content.replace(res[i], "<u>" + sub_string + "</u>");
                //e(""+res[i]);
            }
        }


        var res = content.match(/\[\[[a-zA-Z0-9<>'"\/:\.\s\t\n<>=\?_\-]+\]\]/g);

        if (res != null) {
            e("Image : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("[[");
                index_2 = res[i].indexOf("]]", index_1 + 2);
                sub_string = res[i].substring(index_1 + 2, index_2);
                content = content.replace(res[i], "<img style='max-width:800px;' src='" + sub_string + "' />");
                //e(""+res[i]);
            }
        }
        var res = content.match(/\[[a-zA-Z0-9<>'"\/:\.\s\t\n<>=\#]+\]/g);

        if (res != null) {
            e("Link : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("[");
                index_2 = res[i].indexOf("]", index_1 + 1);
                sub_string = res[i].substring(index_1 + 1, index_2);
                content = content.replace(res[i], "<a href='" + sub_string + "' class='link'>" + sub_string + "</a>");
                //e(""+res[i]);
            }
        }

        var res = content.match(/{{{{[a-zA-Z0-9<>'"\/:\.\s\t\n<>=]+}}}}/g);

        if (res != null) {
            e("Heading  : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("{{{{");
                index_2 = res[i].indexOf("}}}}", index_1 + 4);
                sub_string = res[i].substring(index_1 + 4, index_2);
                content = content.replace(res[i], "<h3>" + sub_string + "</h3>");
                //e(""+res[i]);
            }
        }

        var res = content.match(/{{{[a-zA-Z0-9<>'"\/:\.\s\t\n<>=]+}}}/g);

        if (res != null) {
            e("Heading h2 : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("{{{");
                index_2 = res[i].indexOf("}}}", index_1 + 3);
                sub_string = res[i].substring(index_1 + 3, index_2);
                content = content.replace(res[i], "<h2>" + sub_string + "</h2>");
                //e(""+res[i]);
            }
        }

        var res = content.match(/{{[a-zA-Z0-9<>'"\/:\.\s\t\n<>=]+}}/g);

        if (res != null) {
            e("Heading h1 : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("{{");
                index_2 = res[i].indexOf("}}", index_1 + 2);
                sub_string = res[i].substring(index_1 + 2, index_2);
                content = content.replace(res[i], "<h1>" + sub_string + "</h1>");
                //e(""+res[i]);
            }
        }

        var res = content.match(/##[a-zA-Z0-9<>'"\/:\.\s\t\n<>=]+##/g);

        if (res != null) {
            e("BlockQuote h1 : " + res);
            for (i = 0; i < res.length; i++) {
                index_1 = res[i].indexOf("##");
                index_2 = res[i].indexOf("##", index_1 + 2);
                sub_string = res[i].substring(index_1 + 2, index_2);
                content = content.replace(res[i], "<div style='background:#FFA347;border-left:#FF6600 solid 3px;color:#FFFFFF;padding:5px;'>" + sub_string + "</div>");
                //e(""+res[i]);
            }
        }







        /*
         index_1 = content.indexOf("**");
         index_2 = content.indexOf("**",index_1+2);
         e(index_1 + "   "+index_2);
         if(index_1>-1 && index_2>-1){
         sub_string = content.substring(index_1,index_2);
         content = content.replace(sub_string, "<b>"+sub_string+"</b>");
         }
         */

        content = content.replace(/\n/g, "<br/>");


        $("#Output").text(content);
    }
    function blogsFormat() {
        
        if(event.ctrlKey && String.fromCharCode(event.keyCode)=="B"){
            addBoldBlock();   
        }
        else if(event.ctrlKey && String.fromCharCode(event.keyCode)=="U"){
            addUnderlineBlock();   
        }
        else if(event.ctrlKey && String.fromCharCode(event.keyCode)=="I"){
            addItalicBlock();   
        }
        else if(event.ctrlKey && String.fromCharCode(event.keyCode)=="H"){
            event.preventDefault();
            addH2Block();   
        }
        e("Key : " + String.fromCharCode(event.which));
        updateOutput();
        updatePosition();
        
    }
    pos = {start: 0, end: 0};
    function updatePosition() {
        pos = getCursorPos(ele);
        e(pos.start);
    }
    function addBoldBlock() {
        insertTextAtCursor(ele, "**Bold**");
        setCursorPos(ele, pos.start + 2, pos.start + 2 + 4);
        updateOutput();
        pos.start += 2;
    }
    function addQuoteBlock() {
        insertTextAtCursor(ele, "##Quote##");
        setCursorPos(ele, pos.start + 2, pos.start + 2 + 5);
        updateOutput();
        pos.start += 2;
    }
    function addItalicBlock() {
        insertTextAtCursor(ele, "*Italic*");
        setCursorPos(ele, pos.start + 1, pos.start + 1 + 6);
        updateOutput();
        pos.start += 1;
    }
    function addUnderlineBlock() {
        insertTextAtCursor(ele, "~Underline~");
        setCursorPos(ele, pos.start + 1, pos.start + 1 + 9);
        updateOutput();
        pos.start += 1;
    }
    function addHorizontalLine() {
        insertTextAtCursor(ele, "\n----\n");
        setCursorPos(ele, pos.start + 6, pos.start + 6);
        updateOutput();
        pos.start += 6;
    }
    function addH1Block() {
        e(pos.start);
        insertTextAtCursor(ele, "{{Heading}}");
        setCursorPos(ele, pos.start + 2, pos.start + 2 + 7);
        updateOutput();
        pos.start += 2;
    }
    function addH2Block() {
        e(pos.start);
        insertTextAtCursor(ele, "{{{Heading}}}");
        setCursorPos(ele, pos.start + 3, pos.start + 3 + 7);
        updateOutput();
        pos.start += 3;
    }
    function addH3Block() {
        e(pos.start);
        insertTextAtCursor(ele, "{{{{Heading}}}}");
        setCursorPos(ele, pos.start + 4, pos.start + 4 + 7);
        updateOutput();
        pos.start += 4;
    }
    function addLinkBlock() {
        link = prompt("Enter Link");
        if (link !== false) {
            len = link.length;
            insertTextAtCursor(ele, "[" + link + "]");
            setCursorPos(ele, pos.start + 1, pos.start + 1 + len);
            updateOutput();
            pos.start += 1;
        }
    }
    function addImageBlock() {
        promptImage();
    }
    function promptImage() {
        $("#showPromptImage").show();
    }
    function hidePromptImage() {
        $("#showPromptImage").hide();
    }
    function addImage() {
        hidePromptImage();
        img = $("#imageLink").val();
        altImg = $("#alternateImageLink").val();
        if (img != "") {
            e(pos.start);
            len_img = img.length;
            len_alt = altImg.length;
            img_text = "[[" + img + "]]";
            insertTextAtCursor(ele, img_text);
            setCursorPos(ele, pos.start + 2, pos.start + img_text.length - 2);
            updateOutput();
            pos.start = pos.start + 2;
        }
    }
    function getCursorPos(input) {
        if ("selectionStart" in input && document.activeElement == input) {
            if(input.selectionEnd<input.selectionStart){
                return {
                start: input.selectionEnd ,
                end: input.selectionStart
                 };
            }
            return {
                start: input.selectionStart,
                end: input.selectionEnd
            };
        }
        else if (input.createTextRange) {
            var sel = document.selection.createRange();
            if (sel.parentElement() === input) {
                var rng = input.createTextRange();
                rng.moveToBookmark(sel.getBookmark());
                for (var len = 0;
                        rng.compareEndPoints("EndToStart", rng) > 0;
                        rng.moveEnd("character", -1)) {
                    len++;
                }
                rng.setEndPoint("StartToStart", input.createTextRange());
                for (var pos = {start: 0, end: len};
                        rng.compareEndPoints("EndToStart", rng) > 0;
                        rng.moveEnd("character", -1)) {
                    pos.start++;
                    pos.end++;
                }
                if(pos.end<pos.start){
                    return   {start:pos.end,end:pos.start};
                }
                return pos;
            }
        }
        return -1;
    }
    function setCursorPos(input, start, end) {
        if (arguments.length < 3)
            end = start;
        if ("selectionStart" in input) {
            setTimeout(function() {
                input.selectionStart = start;
                input.selectionEnd = end;
            }, 1);
        }
        else if (input.createTextRange) {
            var rng = input.createTextRange();
            rng.moveStart("character", start);
            rng.collapse();
            rng.moveEnd("character", end - start);
            rng.select();
        }
    }
    function insertTextAtCursor(el, text) {
        var val = el.value, endIndex, range;
        if (typeof el.selectionStart != "undefined" && typeof el.selectionEnd != "undefined") {
            if(el.selectionEnd<el.selectionStart){
             el.dummySelectionEnd = el.selectionEnd;
             el.selectionEnd=el.selectionStart;
             el.selectionStart=el.dummySelectionEnd;
            }
            endIndex = el.selectionEnd;
            el.value = val.slice(0, el.selectionStart) + text + val.slice(endIndex);
            el.selectionStart = el.selectionEnd = endIndex + text.length;
        } else if (typeof document.selection != "undefined" && typeof document.selection.createRange != "undefined") {
            el.focus();
            range = document.selection.createRange();
            range.collapse(false);
            range.text = text;
            range.select();
        }
    }