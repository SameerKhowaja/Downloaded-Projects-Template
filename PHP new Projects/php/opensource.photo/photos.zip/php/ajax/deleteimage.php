<?php
include_once "../session/session_start.php";
include_once "../class/query.php";
$img = isset($_POST["img"])?$_POST["img"]:"";
$userid = isset($_SESSION['userid'])?$_SESSION['userid']:-10;
if(QUERY::c("select count(*) from images where userid=$userid and img='{$img}'")=="1"){
    QUERY::query("update images set enable=1  where img='{$img}'");
    echo "OK";
}else{
    echo "NOTOK";
}

?>