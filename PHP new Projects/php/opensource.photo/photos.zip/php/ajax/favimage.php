<?php
include_once "../session/session_start.php";
include_once "../class/query.php";
$img = isset($_POST["img"])?$_POST["img"]:"";
if(!isset($_SESSION['userid'])){
    echo "NOTOK";
    exit;
}
$userid = $_SESSION['userid'];
$OP = $_POST["do"];
$imageid = QUERY::c("select imgid from images where img='{$img}'");
if($OP=="fav"){
    if(QUERY::c("select count(*) from imagefav where imgid=$imageid && userid=$userid")=="0"){
        QUERY::query("insert into imagefav(userid,imgid) values($userid,$imageid)");
         echo "OK";
    }else{
        echo "Already Fav";
    }
}else if($OP=="unfav"){
    if(QUERY::c("select count(*) from imagefav where imgid=$imageid && userid=$userid")=="1"){
        QUERY::query("delete from imagefav where imgid=$imageid && userid=$userid");
         echo "OK";
    }else{
        echo "Already Unfav";
    }
}

?>