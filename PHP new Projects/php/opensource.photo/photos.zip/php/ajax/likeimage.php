<?php
include_once "../session/session_start.php";
include_once "../class/query.php";
$img = isset($_POST["img"])?$_POST["img"]:"";
if(!isset($_SESSION['userid'])){
    echo "NOTOK";
    exit;
}
$userid = $_SESSION['userid'];
$OP = $_POST["do"];
$imageid = QUERY::c("select imgid from images where img='{$img}'");
if($OP=="like"){
    if(QUERY::c("select count(*) from imagelike where imgid=$imageid && userid=$userid")=="0"){
        QUERY::query("insert into imagelike(userid,imgid) values($userid,$imageid)");
        echo "OK";
    }else{
        echo "Already Liked";
    }
}else if($OP=="unlike"){
    if(QUERY::c("select count(*) from imagelike where imgid=$imageid && userid=$userid")=="1"){
        QUERY::query("delete from imagelike where imgid=$imageid && userid=$userid");
         echo "OK";
    }else{
        echo "Already unliked";
    }
}

?>