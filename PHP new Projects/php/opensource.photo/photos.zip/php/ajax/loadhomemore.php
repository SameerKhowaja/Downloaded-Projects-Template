<?php
include_once "../class/query.php";
include_once "../class/images.php";
$POST_PER_PAGE=12;
$PAGE_NO=$_POST['pageno'];
$START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
                    $query = "select * from images where privacy=0 && enable=0 order by time desc";
                 
                    $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
                    
                    while ($result = mysqli_fetch_array($res)) {
                        IMAGES::card($result['img'], $result['userid'], $result['time']);
                    }


?>
