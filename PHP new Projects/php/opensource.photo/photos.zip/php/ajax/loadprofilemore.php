<?php

include_once "../session/session_start.php";
include_once "../class/query.php";
include_once "../class/images.php";
$POST_PER_PAGE = 12;
$PAGE_NO = $_POST['pageno'];
$PROFILE_USERNAME = $_POST['name'];
$PROFILE_USERID = QUERY::c("select userid from usersignup where username='{$PROFILE_USERNAME}' && enable=0");
$START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
$CURRENT_USER_ID = isset($_SESSION['userid']) ? $_SESSION['userid'] : -10;
$query = "select * from images where (privacy=0 || $CURRENT_USER_ID=userid) userid=$PROFILE_USERID order by time desc";
$COUNT_QUERY = $query;
$res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
while ($result = mysqli_fetch_array($res)) {
    IMAGES::card($result['img'], $result['userid'], $result['time']);
}


?>
