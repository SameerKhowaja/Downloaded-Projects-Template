<?php
include_once "../session/session_start.php";
include_once "../class/query.php";
$img = isset($_POST["img"])?$_POST["img"]:"";
$userid = isset($_SESSION['userid'])?$_SESSION['userid']:"";
if(QUERY::c("select count(*) from images where userid=$userid and img='{$img}'")=="1"){
    QUERY::query("update usersignup set cover='{$img}' where userid=$userid");
    echo "OK";
}else{
    echo "NOTOK";
}

?>