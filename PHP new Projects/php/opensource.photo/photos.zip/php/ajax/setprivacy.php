<?php
include_once "../session/session_start.php";
include_once "../class/query.php";
$img = isset($_POST["img"])?$_POST["img"]:"";
$privacy = isset($_POST["privacy"])?($_POST["privacy"]=="Public")?0:1:1;
$userid = isset($_SESSION['userid'])?$_SESSION['userid']:"";
if(QUERY::c("select count(*) from images where userid=$userid and img='{$img}'")=="1"){
    QUERY::query("update images set privacy=$privacy  where img='{$img}'");
    echo "OK";
}else{
    echo "NOTOK";
}

?>