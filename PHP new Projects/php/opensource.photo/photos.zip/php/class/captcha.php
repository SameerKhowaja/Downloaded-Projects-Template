<?php
class CAPTCHA{
static function  get($type)
  {
$nocic=1;
$rand1 = rand(10,60);
$rand2 = rand(10,25);	
$content=substr(md5(rand()),0,$nocic);
$c=$content;
$token=rand(0,10);
$_SESSION['capitcha'.$type][$token]=$c;
return "<div><span class='capitcha'><span class='capitchaspan' style='left:{$rand1}px;top:{$rand2}px;' unselectable='on' id='capitchacontent'>{$c}</span></span><span><input type='button' value='change' onclick='changecapitcha".$type."()'/></span></div><div><br/><input type='text' placeholder='enter capitcha' id='capitcha' data-token='{$token}'  name='capitcha'/><span id='errorcapitcha' class='error'></span></div>";  
  }
}

?>