<?php

class common
{
    public static $con;
    public static $pathname;
    public static $sitepath;
    public static $sitename;
    public static $isloggedin = false;

    function __construct()
    {
        $host = "localhost";
        $user = "root";
        $pass = "";
        $db = "photos";
        $con = mysqli_connect($host, $user, $pass, $db);
        if (!$con) {
            echo mysqli_error($con);
            exit();
        }
        common::$con = $con;
        if (isset($_SESSION['username'])) {
            common::$isloggedin = true;
        }
    }
}

?>
