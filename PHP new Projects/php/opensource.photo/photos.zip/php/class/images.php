<?php

class IMAGES {

    static function card($img, $userid, $time) {
        $username = ucfirst(QUERY::c("select username from usersignup where userid=$userid"));
        $imageid = QUERY::c("select imgid from images where img='{$img}'");
        $date = explode(" ", $time);
        $date = $date[0];
        $dateObject = date_create($time);
//$fullDate= date_format($dateObject, 'Y-M-D H:i:s');
        $fullDate = date_format($dateObject, 'l,F d,Y, \a\t G:ia');
        $date = IMAGES::gettime(strtotime(QUERY::c("select current_timestamp from dual"))-strtotime($time));
        $isEditor = (QUERY::c("select count(*) from images where img='{$img}' and editors_pick IN (1,2)")=="1")?"isEditorPick":"";
        $isPrivate = (QUERY::c("select count(*) from images where img='{$img}' and privacy<>0")=="1")?"isPrivatePhoto":"";
        $title  = QUERY::c("select title from images where img='{$img}'");
        $CURR_USERID = (isset($_SESSION['userid']))?$_SESSION['userid']:-10;
        $isLiked = QUERY::c("select count(*) from imagelike where imgid=$imageid && userid=$CURR_USERID");
        $isFav = QUERY::c("select count(*) from imagefav where imgid=$imageid && userid=$CURR_USERID");
        echo "<ul class='fl images' itemscope itemtype='http://schema.org/ImageObject' >"
        . "<li><div  style='background:url(/uploads/thumb/$img);height:200px;background-repeat:no-repeat;background-size:cover;position:relative;' class='img fl' itemprop='contentUrl' height='200' alt='images'  onclick='loadFullImage(\"$img\")'>"
                . "<div class='hoverShowTitle'>"
                . "<span style='width:75%;display:inline-block;word-break:break-all;'>$title</span>"
                . "<ul class='hl' style='display:inline-block;float: right; margin-right: 5px;'>"
                . "<li style='margin-right:10px;'><img src='/img/like_normal.png?a' width='20' height='20' style='display:".(($isLiked=="0")?"block":"none")."' id='like_{$img}' onclick='likeImagesCard(\"{$img}\")'/></li>"
                . "<li style='margin-right:10px;'><img src='/img/like_highlight.png' width='20' height='20' style='display:".(($isLiked=="0")?"none":"block")."' id='dislike_{$img}' onclick='dislikeImagesCard(\"{$img}\")' /></li>"
                
                . "<li><img src='/img/fav_normal.png?1' width='20' height='20' style='display:".(($isFav=="0")?"block":"none")."' id='fav_{$img}' onclick='favImagesCard(\"{$img}\")'/></li>"
                . "<li><img src='/img/fav_highlight.png' width='20' height='20' style='display:".(($isFav=="0")?"none":"block")."' id='unfav_{$img}' onclick='unfavImagesCard(\"{$img}\")' /></li>"
                . "</ul>"
                . "</div>"
                . "</div></li>"
        . "<!--<li class='extraInfo'>"
                ."<ul class='verticalList'><li>"
                . "<span class='fl'><a href='/$username' class='link' itemprop='author'>$username</a></span><span class='fr time' itemprop='datePublished' content='{$date}'>$date<span class='fulltime'>$fullDate</span></span>"
                        ."</li>"
                        . "<li class='editorsLine $isEditor $isPrivate' title='Editors Pick'></li>"
                        . "</ul>"
                        . "</li>-->"
                . "</ul>";
    }

    static function album1($albumid) {
        $albumName = QUERY::c("select album from album where albumid=$albumid");
        $albumusername = QUERY::c("select username from usersignup where userid=(select userid from album where albumid=$albumid)");
        $albumTime = QUERY::c("select time from album where albumid=$albumid");
        $albumuserid = QUERY::c("select userid from usersignup where username='{$albumusername}'");
        $albumTime = explode(" ", $albumTime);
        $albumTime = $albumTime[0];
        ?>
        <ul class="albums">
            <li class="profileAlbumName">
                <a href="/////<?php echo $albumusername; ?>/albums/<?php echo $albumName; ?>/" class="link">
                    <?php echo $albumName; ?>
                </a>
                <span class="fr">////<?php echo $albumTime; ?></span>
            </li>
            <li>
                <?php
                $CURRENT_USER_ID = isset($_SESSION['userid'])?$_SESSION['userid']:-10;
                $MAX_NUMBER_IMG_ALBUM = 5;
                $COUNT = QUERY::c("select count(*) from images where userid=$albumuserid and albumid=$albumid");
                $res = QUERY::query("select * from images where (privacy=0 || userid=$CURRENT_USER_ID) and albumid=$albumid order by time desc limit $MAX_NUMBER_IMG_ALBUM");

                while ($result = mysqli_fetch_array($res)) {
                    $img = $result['img'];
                    echo "<img src='/uploads/thumb/$img' height='100' alt='images' class='albumImg' onclick='loadAlbumImage(\"$img\")'/>";
                }
                if ($COUNT > $MAX_NUMBER_IMG_ALBUM) {
                    echo "<a href='/$albumusername/albums/$albumName' class='link '><img class='albumImg' alt='images' src='/img/more.png' height='100'/></a>";
                }
                ?>
            </li>
        </ul>
        <?php
    }
    
    static function album($albumid) {
        $albumName = QUERY::c("select album from album where albumid=$albumid");
        $albumusername = QUERY::c("select username from usersignup where userid=(select userid from album where albumid=$albumid)");
        $albumTime = QUERY::c("select time from album where albumid=$albumid");
        $albumuserid = QUERY::c("select userid from usersignup where username='{$albumusername}'");
        $albumTime = explode(" ", $albumTime);
        $albumTime = $albumTime[0];
        ?>
       <ul class="albums" style="width: 47.5%;float: left;margin-right: 2%;"> 
            <li class="profileAlbumName" style="width: 98%;padding: 1%;margin: 0%;border: none;">
                <a href="/<?php echo $albumusername; ?>/albums/<?php echo $albumName; ?>/" class="link">
                    <?php echo $albumName; ?>
                </a>
                <span class="fr" style="color:#888;font-size: 0.8em;"><?php echo $albumTime; ?></span>
            </li>
            <li style="width: 100%;">
                <?php
                $CURRENT_USER_ID = isset($_SESSION['userid'])?$_SESSION['userid']:-10;
                $MAX_NUMBER_IMG_ALBUM = 4;
                $COUNT = QUERY::c("select count(*) from images where userid=$albumuserid && enable=0 && albumid=$albumid");
                $res = QUERY::query("select * from images where (privacy=0 || userid=$CURRENT_USER_ID) && enable=0 && albumid=$albumid order by time desc limit $MAX_NUMBER_IMG_ALBUM");

                while ($result = mysqli_fetch_array($res)) {
                    $img = $result['img'];
                    echo "<img src='/uploads/thumb/$img' height='100' alt='images' class='albumImg' style='background-color:#FFF;min-width:48%;max-width:48%;min-height:150px;margin:0.5%;padding:0.5%;' onclick='loadAlbumImage(\"$img\")'/>";
                }
                for($i=$COUNT;$i<$MAX_NUMBER_IMG_ALBUM;$i++){
                    echo "<img src='/img/defaultalbum.png' height='100' class='albumImg' style='cursor:auto;background-color:#FFF;overflow: hidden;min-width:48%;max-width:48%;min-height:150px;margin:0.5%;padding:0.5%;'/>";
                }
                ?>
            </li>
        </ul>
        <?php
    }

    static function singleAlbum($albumid) {
        $albumName = QUERY::c("select album from album where albumid=$albumid");
        $albumusername = QUERY::c("select username from usersignup where userid=(select userid from album where albumid=$albumid)");
        $albumTime = QUERY::c("select time from album where albumid=$albumid");
        $albumTime = explode(" ", $albumTime);
        $albumTime = $albumTime[0];
        ?>
        <ul class="albums">
            <li class="profileAlbumName">
                <a href="/<?php echo $albumusername; ?>/albums/<?php echo $albumName; ?>/" class="link">
                    <?php echo $albumName; ?>
                </a>
                <span class="fr"><?php echo $albumTime; ?></span>
            </li>
            <li class="singleAlbumImg">
                <?php
                $res = QUERY::query("select * from images where albumid=$albumid order by time desc");
                while ($result = mysqli_fetch_array($res)) {
                    $img = $result['img'];
                    IMAGES::card($result['img'], $result['userid'], $result['time']);             
                    //echo "<img src='/uploads/thumb/$img' height='200' alt='images' class='albumImg' onclick='loadAlbumImage(\"$img\")'/>";
                }
                ?>
            </li>
        </ul>
        <?php
    }

    static function gettime($time) {
        $count = 0;
        if ($time < 10) {
            return "just now";
        } else if ($time < 60) {
            return $time . " seconds ago";
        } else if ($time < 60 * 60) {
            $count = round($time / 60);
            return $count . " minute ago";
        } else if ($time < 60 * 60 * 24) {
            $count = round($time / 3600);
            return $count . " hours ago";
        } else if ($time < 60 * 60 * 24 * 7) {
            $count = round($time / 86400);
            return $count . " days ago";
        } else if ($time < 60 * 60 * 24 * 7 * 4) {
            $count = round($time / 604800);
            return $count . " weeks ago";
        } else if ($time < 60 * 60 * 24 * 30 * 12) {
            $count = round($time / 2592000);
            return $count . " month ago";
        } else {
            $count = round($time / (60 * 60 * 24 * 30 * 12));
            return $count . " years ago";
        }
    }

}
?>