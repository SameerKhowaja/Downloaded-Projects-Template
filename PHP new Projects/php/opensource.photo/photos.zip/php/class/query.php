<?php
// add @ after website is complete
require_once "common.php";
class QUERY extends common{
	public static $connect;
	function __construct(){
	 parent::__construct();
	 QUERY::$connect=common::$con;	 	
	}
	static function query($query){
		return mysqli_query(QUERY::$connect,$query); 		
	}
	static function  c($query){
		  $result=QUERY::query($query);
		  $res=mysqli_fetch_array($result);
		  return $res[0];		
	}
	static function QA($query){
		return mysqli_fetch_array(mysqli_query(QUERY::$connect,$query));
	}
	static function insert($query){
		return mysqli_query(QUERY::$connect,$query); 
	}
	static function update($query){
		return mysqli_query(QUERY::$connect,$query); 	
	}
	static function delete($query){
	    return mysqli_query(QUERY::$connect,$query); 		
	}
	static function select ($query){
		return mysqli_query(QUERY::$connect,$query); 	
	}
        static function error (){
		return mysqli_error(QUERY::$connect); 	
	}
}
$QUERY = new QUERY();
?>
