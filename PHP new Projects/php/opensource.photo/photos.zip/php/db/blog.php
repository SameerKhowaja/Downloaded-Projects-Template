<?php
include_once "../session/session_start.php";
include_once "../class/query.php";

if(!isset($_SESSION['userid'])){
    echo "NOTOK";exit();
}
$userid=$_SESSION['userid'];
$title = $_POST['title'];
$desc = $_POST['desc'];
$title=mysqli_real_escape_string(QUERY::$con,$title);
$title=htmlspecialchars($title);
$desc=mysqli_real_escape_string(QUERY::$con,$desc);
$desc=htmlspecialchars($desc);
QUERY::query("insert into blog(title,blog,userid) values('{$title}','{$desc}',$userid)");


?>