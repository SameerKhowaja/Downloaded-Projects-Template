<?php
ob_start();
include_once "../session/session_start.php";
include_once "../class/query.php";

$username=$_POST['username'];
$pattern="/[^a-zA-Z0-9._]/";
if(!preg_match($pattern,$username)){
	//include "";
}else{
echo "IUSER";	
exit();	
}
$pattern="/[^a-zA-Z0-9\._\?@]/";
$password=$_POST['pass'];
if(!preg_match($pattern,$password)){
	//include "";
}else{
echo "IPASS";	
exit();	
}


$password=md5($password);
$query="select count(*) as coun from usersignup where username='{$username}' and password='{$password}'";
/*$result=mysqli_query($con,$query);
$res = mysqli_fetch_array($result);*/
$decider=QUERY::c($query);
if($decider==0){
echo "NOTOK";	
}
else{
	if(QUERY::c("select count(*) from usersignup where username='{$username}' and status=0")!=1){
		echo "BANNED";
		exit;
	};

echo "OK";
$query="select username,userid,logininfo from usersignup where username='{$username}' and password='{$password}'";
$res=QUERY::QA($query);
$username=$res['username'];
$userid=$res['userid'];
$logininfo=$res['logininfo'];
$_SESSION['username']=$username;
$_SESSION['userid']=$userid;
$_SESSION['logininfo']=$logininfo;
	  if(isset($_POST['remem'])){
		  if($_POST['remem']=="true"){
			  $expire=time()+60*60*24*30*3;
			   setcookie("a",$username,$expire,"/");
			   setcookie("logininfo",$logininfo,$expire,"/");	   
		  }
	  }
}
?>