<?php
include_once "../class/query.php";
include_once "../session/session_start.php";

$username=$_POST['username'];
$pattern="/[^a-zA-Z0-9_@]/";
if(!preg_match($pattern,$username)){

}else{
echo "IUSER";	
exit();	
}
$pattern="/[^a-zA-Z0-9\._@\?]/";
$password=$_POST['pass'];
if(!preg_match($pattern,$password)){
}else{
echo "IPASS";	
exit();	
}
$capitcha=$_POST['capitcha'];
if($username=="" || $password==""){
echo "REQUI";
exit();	
}
$token=$_POST['token'];
if($capitcha!=$_SESSION['capitchasignup'][$token]){
	echo "CAPIT";
        $nocic=1;
	$c = substr(md5(rand()),0,$nocic);
$_SESSION['capitchasignup'][$token]=$c;
echo $c;
	exit();
}

if(isset($_SESSION['capitchasignup'][$token])){
$_SESSION['capitchasignup'][$token]=null;
}

$privatename=array("editors","hash","search","blog","profile","etc","php","css","js","t","s","img","pimg","tags","login","activity","m","messages","signup","about","help","suggest","bottom","ar","default","mobile","link","text","dev","d","new","view","rising","top","hot","photos","albums","hash","tags","pages","page","api");
if(in_array($username,$privatename)){
echo "NOTOK56788";
exit();	
}

$query="select count(*) as coun from usersignup where username='{$username}'";
$decider=QUERY::c($query);
if($decider!=0){
echo "NOTOK1223";
exit();		
}
else{
$password=md5($password);	
$i=md5(rand());
$query="insert into usersignup(username,password,logininfo) values('$username','{$password}','{$i}')";
$result=QUERY::insert($query);
 echo "OK";	  
}
?>