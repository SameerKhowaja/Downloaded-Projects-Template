<?php
$PAGE_NO = 1;
$TYPE = (isset($pArray[2])) ? $pArray[2] : "";
if (is_numeric($TYPE) || $TYPE == "") {
    $PAGE_NO = 1;
    $TYPE = "BLOG_LIST";
}
?>
<?php
if ($TYPE == "submit") {
    ?>
    <div id="showPromptImage"
         style="background: #111;opacity:0.9;position:fixed;top:0px;left:0px;width:100%;display: none;margin:0 auto;">
        <div id="" style="height:500px;width:400px;margin:0 auto;">
            <h3 style="color: #FFFFFF;">Add Image</h3>
            <div><input id="imageLink" class='input' autofocus="true" type="text" placeholder="Enter Image Link"/></div>
            <div><input id="alternateImageLink" class='input' type="text" placeholder="Enter Alternate text"/></div>
            <div><input type="button" value="Add Image" onclick="addImage()"/><input type="button" value="Cancle"
                                                                                     onclick="hidePromptImage()"/></div>
        </div>
    </div>
    <div><h2>Blog</h2></div>
    <div><h3>Title</h3></div>
    <div><input type="text" placeholder="Enter Title For Your Blog" class="input" id="blogTitle"/></div>
    <div><h3>Description</h3></div>
    <div id="optionFormat">
        <input type="button" value="B" onclick="addBoldBlock()"/>
        <input type="button" value="I" onclick="addItalicBlock()"/>
        <input type="button" value="U" onclick="addUnderlineBlock()"/>
        <input type="button" value="Quote" onclick="addQuoteBlock()"/>
        <input type="button" value="H1" onclick="addH1Block()"/>
        <input type="button" value="H2" onclick="addH2Block()"/>
        <input type="button" value="H3" onclick="addH3Block()"/>
        <input type="button" value="Link" onclick="addLinkBlock()"/>
        <input type="button" value="Image" onclick="addImageBlock()"/>
        <input type="button" value="Hr" onclick="addHorizontalLine()"/>
    </div>
    <div id="Input">
        <textarea id="inputContent" class="input" spellcheck='false' rows="10" cols="70" onmousedown="updatePosition()"
                  onmouseup="updatePosition()" onfocus="updatePosition()" onkeyup="blogsFormat()"></textarea>
    </div>
    <div><h3>Preview</h3></div>
    <div id="Output"></div>
    <p></p>
    <div><input type="button" value="Submit Blog" class="input" onclick="submitBlog()"/></div>
    <p></p>
    <?php
} else if ($TYPE == "BLOG_LIST") {
    $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
    $query = "select * from blog order by time desc";
    $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");

    if(mysqli_num_rows($res)==0)
    {
        echo "<h2>Blog List is Empty.</h2>";
    }else {
        while ($result = mysqli_fetch_array($res)) {
            $title = $result['title'];
            $time = $result['time'];
            $id = $result['blogid'];
            $user_id = $result['userid'];
            $username = QUERY::c("select username from usersignup where userid=$user_id");
            $titleLink = str_replace(" ", "-", strtolower($title));
            $titleLink = str_replace("#", "", strtolower($titleLink));

            $dateObject = date_create($time);
            $fullDate = date_format($dateObject, 'l,F d,Y, \a\t G:ia');

            echo "<div><a href='/blog/$titleLink/$id' class='link'><h2>$title</h2></a><div><a class='link' href='/$username'>$username </a> <span style='font-size:15px;'>$fullDate</span></div></div>";
        }
    }
} else {
    $BLOG_ID = (isset($pArray[3])) ? is_numeric($pArray[3]) ? $pArray[3] : -1 : -1;
    $query = "select * from blog where blogid=$BLOG_ID";
    $res = QUERY::query("$query");
    while ($result = mysqli_fetch_array($res)) {
        $title = $result['title'];
        $id = $result['blogid'];
        $blog = $result['blog'];
        $time = $result['time'];
        $titleLink = str_replace(" ", "-", strtolower($title));
        $userId = $result['userid'];
        $userName = QUERY::c("select username from usersignup where userid=$userId");
        $userImage = QUERY::c("select img from usersignup where userid=$userId");
        $seconds = strtotime(QUERY::c("select current_timestamp from dual")) - strtotime($time);
        $displayTime = IMAGES::gettime($seconds);
        echo "<div class='blogUser'><ul class='horizontalList' ><li><img src='/uploads/profile/thumb/$userImage' width='50' alt='img'/></li><li><ul style='padding-left:10px;'><li><a href ='/$userName' class='link'>$userName</a></li><li>$displayTime</li></ul></li></ul></div>";
        echo "<h2>$title</h2>";
        echo "<textarea class='none' id='inputContent' onload='updateOutput()'>$blog</textarea>";
        echo "<div id='Output'></div>";

        echo "<script>window.onload=function(){updateOutput();$('.middle').css('background-color:#FFF;');$('.mainContent').css('padding-left:10px;width:99%;');}</script>";
        echo "<p></p>";

    }
}
?>
<script>
    function submitBlog() {
        title = $("#blogTitle").val();
        desc = $("#inputContent").val();
        title = encodeURIComponent(title);
        desc = encodeURIComponent(desc);
        xml = post("/php/db/blog.php", "title=" + title + "&desc=" + desc);
        window.location.href = '/blog/';
    }
    <?php
    include "js/blog_format.js";
    ?>
</script>
