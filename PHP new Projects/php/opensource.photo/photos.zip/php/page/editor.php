<?php

$query = "select * from images  where editors_pick=2 order by time desc";
$res = QUERY::query("$query limit 5");

$EDITORS_PICK_COUNT = mysqli_num_rows($res);

echo "<li id='loadMore'>";
$id = 0;
if ($EDITORS_PICK_COUNT == 0) {
    echo "<h2>Editor has Yet Not Picked Any Photo.</h2>";
}
echo "<div style='position:relative;overflow:hidden;height:400px;'>";
while ($result = mysqli_fetch_array($res)) {
    $id++;
    $img = $result['img'];
    echo "<img src='/uploads/original/$img' class='editorsPicImg' style='height:0px;opacity:0;' id='_$id'/>";
    //IMAGES::card($result['img'], $result['userid'], $result['time']);
}
echo "</div>";
echo "</li>";
?>
<?php
$PAGE_NO = 1;
if (isset($pArray['1'])) {
    if (is_numeric($pArray['1'])) {
        $PAGE_NO = $pArray['1'];
    }
}
$START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
//$START_POST +=5;
$query = "select * from images where editors_pick=1 order by time desc limit $START_POST,$POST_PER_PAGE";
$COUNT_QUERY = $query;
$res = QUERY::query($query);
$EDITORS_PICK_COUNT += mysqli_num_rows($res);
echo "<li id='loadMore'>";

while ($result = mysqli_fetch_array($res)) {
    $img = $result['img'];
    //echo "<img src='/uploads/thumb/$img' class='editorsPicImg' style='height:0px;opacity:0;'/>";
    IMAGES::card($result['img'], $result['userid'], $result['time']);
}


echo "</li>";
?>

<script>
    editors_id = 0;
    function rotateImg() {
        editors_id++;
        $("#_" + editors_id).css("height:400px");
        $("#_" + editors_id).css("opacity:1;");

        setTimeout(function () {
            $("#_" + editors_id).css("height:0px;");
            $("#_" + editors_id).css("opacity:0;");
            editors_id++;
            editors_id %= 3;
            rotateImg();
        }, 6000);
    }
    rotateImg();
</script>