<?php

$PAGE_NO = 1;

if (isset($pArray['3'])) {
    if (is_numeric($pArray['3'])) {
        $PAGE_NO = $pArray['3'];
    }
}
$HASH = "";
if (isset($pArray['2'])) {
    if (!is_numeric($pArray['2'])) {
        $HASH = $pArray['2'];
    } else {
        
    }
}
if ($HASH != "") {
    $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
    $query = "select * from images  where title like '%#$HASH%' order by time desc";
    $COUNT_QUERY = $query;
    $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
    echo "<h2><span style='font-size:3em;color:#888;margin-right:10px;'>#</span><span>$HASH</span></h2>";
    echo "<li id='loadMore'>";

    if(mysqli_num_rows($res)==0)
    {
        echo "<h2>No Images Found With That Hash Tag.</h2>";
    }else {
        while ($result = mysqli_fetch_array($res)) {
            IMAGES::card($result['img'], $result['userid'], $result['time']);
        }
    }
    echo "</li>";
} else {
    $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
    $query = "select title from images where title like '%#_%'";
    $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
    echo "<div style='padding-top: 20px;overflow: hidden;word-break: break-all;font-size:10px;'>";
    $ARRAY_WORD = array();
    if(mysqli_num_rows($res)==0)
    {
        echo "<h2>Hash List is Empty.</h2>";
    }else {
        while ($result = mysqli_fetch_array($res)) {
            $title = $result['title'];
			$titleArray = explode(" ",$title);
			foreach ($titleArray as $valueArray) {
					if(substr($valueArray,0,1)=="#")
					{
						$ARRAY_WORD[] = substr($valueArray,1);
					}
			}
        }
    }
    
    $ARRAY_WORD_COUNT_DISTINCT = array_count_values(array_map('strtolower', $ARRAY_WORD));
    $ONLY_VALUE = array_values($ARRAY_WORD_COUNT_DISTINCT);

    $MAX_COUNT_IN_ARRAY =  @max($ONLY_VALUE);
    $MIN_COUNT_IN_ARRAY =  @min($ONLY_VALUE);
    $MAX_SIZE = 10;
    $MIN_SIZE = 1;
    
    
    foreach($ARRAY_WORD_COUNT_DISTINCT as $key => $value) {
        // newvalue= (max'-min')/(max-min)*(value-max)+max'
			$DIFF = ($MAX_COUNT_IN_ARRAY - $MIN_COUNT_IN_ARRAY);
			if($DIFF<=0)
			{
				$DIFF = 1;
			}
            $size = ($value - $MIN_COUNT_IN_ARRAY)/$DIFF;
            $size*=($MAX_SIZE);
             $size = ($MAX_SIZE - $MIN_SIZE)/$DIFF*($value - $MAX_COUNT_IN_ARRAY) + $MAX_SIZE;
            echo "<a href='/hash/$key' class='link hashLink' style='display:inline-block;font-size:{$size}em;'>#$key</a>";
    }
    
    echo "</div>";
}
?>