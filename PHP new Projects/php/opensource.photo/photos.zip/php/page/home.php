<?php
$PAGE_NO = 1;
                    if (isset($pArray['1'])) {
                        if (is_numeric($pArray['1'])) {
                            $PAGE_NO = $pArray['1'];
                        }
                    }

                    $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
                    $query = "select * from images where privacy=0 && enable=0 order by time desc";
                    $COUNT_QUERY = $query;
                    $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
                    echo "<li id='loadMore'>";
                    while ($result = mysqli_fetch_array($res)) {
                        IMAGES::card($result['img'], $result['userid'], $result['time']);
                    }
                    echo "</li>";

                    if(mysqli_num_rows($res)==0){
                        echo "<h2>No Images Are added.</h2>";
                    }else if(mysqli_num_rows($res)<=15){
                        echo "<p style='color: #777777;text-align: center;'>No More Images.</p>";
                    }else {
                        echo "<li><div id='homeLoadProgress' style='width:100%;height:3px;background:#FF6600;left:-100%;display:none;position:fixed;top:0px;'></div>";
                        echo "<div onclick='loadHomeMore()' id='moreHomePageButton' class='center'>"
                            . "<span class='moreBox center'>Load more</span>"
                            . "</div>";
                    }
                    echo "</li>";
?>