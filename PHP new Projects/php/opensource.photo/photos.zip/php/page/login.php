<li>
                    <div class="loginBox">
                        <div class="loginBoxContainer">
                            <div class="loginTitle">   <img src="/img/icon.png" width="100" height="40" alt="home"/> </div>
                            <div class="error" id="wrongpassword"></div>
                            <div>   Username   </div>
                            <div><input type="text" class="input" placeholder="Enter Your Username" id="loginName"/></div>
                            <div>   Password   </div>
                            <div><input type="password" class="input" placeholder="Enter Your Password" id="loginPass"/></div>
                            <div><input type="checkbox" id="logincheckbox" /> remember password</div>
                            <div><input type="button" class="input" value="Log in" onclick="login()"/></div>
                            <div><div><a href="/signup" class="link">Create account?</a></div></div>
                        </div>
                    </div>
                    <script type="text/javascript">function login(){var e=$("#loginName").val(),t=$("#loginPass").val(),a=_("logincheckbox").checked;""!=e&&""!=t&&(xmlhttp=post("/php/db/login.php","username="+e+"&pass="+t+"&remem="+a),text=xmlhttp.responseText,text=text.substr(0,5),"NOTOK"==text?$("#wrongpassword").text("username or password is wrong!! try again"):"IUSER"==text?$("#wrongpassword").text("username only contain alphabate number and special char(_)"):"IPASS"==text?$("#wrongpassword").text("password only contain alphabate number and special char(_,?,@)"):"BANNE"==text?$("#wrongpassword").text('You have been banned..<a href="">Why?</a>'):"COUNT"==text?$("#wrongpassword").text("You'r country has been blocked<a href=''>Why?</a>"):"IPBAN"==text?$("#wrongpassword").text("You'r IP has been blocked<a href=''>Why?</a>"):window.location.href=window.location.href)}
                    </script>
                    </li>