<?php
$p1 = $_SERVER['REQUEST_URI'];
$p1 = str_replace("http://", "", $p1);
$URI_ARRAY = explode("/", $p1);
$URI_CURRENT = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$image = (isset($URI_ARRAY[3])) ? $URI_ARRAY[3] : "";
$CURRENT_USER_ID = isset($_SESSION['userid']) ? $_SESSION['userid'] : -10;
if (QUERY::c("select count(*) from images where (privacy=0 or userid=$CURRENT_USER_ID) and img='{$image}'") != "1") {
    $PAGE = "ERROR";
    return;
}
$_IMAGE = $image;
$TITLE = QUERY::c("select title from images where img='{$image}'");
$VIEW = QUERY::c("select view from images where img='{$image}'");
$TIME = QUERY::c("select time from images where img='{$image}'");
$USERNAME = QUERY::c("select username from usersignup where userid=(select userid from images where img='{$image}')");
$USER_IMG = QUERY::c("select img from usersignup where username='{$USERNAME}'");
$PHOTOS = QUERY::c("select count(*) from images where userid=(select userid from images where img='{$image}')");
$ALBUMS = QUERY::c("select count(*) from album where userid=(select userid from images where img='{$image}')");

$dateObject = date_create($TIME);
$FULL_TIME = date_format($dateObject, 'l,F d,Y, \a\t G:ia');
?>
<h2><?php echo ucfirst($TITLE); ?></h2>
<div style="text-align: right;">Views : <?php echo $VIEW; ?></div>
<div style="text-align: center;background:#111;"><img src="/uploads/original/<?php echo $image; ?>" style="max-width:100%;background: #FFF;"/></div>
<p></p>
<div style="overflow: hidden;">
    <script>
        function showImageDetail() {
            width = $("#photoDetailTable").css("height");

            $("#photoDetail").css("height:" + width + ";");
            $("#showPhotDetailButton").hide();
            $("#hidePhotDetailButton").show();
        }
        function hideImageDetail() {
            $("#photoDetail").css("height:0px;");
            $("#hidePhotDetailButton").hide();
            $("#showPhotDetailButton").show();
        }
    </script>
    <ul >
        <li>
            <div style="overflow: hidden;">
                <ul class="horizontalList" style="width: 360px;margin:0 auto;">
                    <li class="socialItem socialFB"><a href='https://www.facebook.com/sharer/sharer.php?u=<?php echo $URI_CURRENT; ?>' class="link">f</a></li>
                    <li class="socialItem socialT"><a href='https://twitter.com/intent/tweet?text=<?php echo $TITLE; ?>&url=<?php echo $URI_CURRENT; ?>&via=initedit' class="link">t</a></li>
                    <li class="socialItem socialG"><a href='https://plus.google.com/share?url=<?php echo $URI_CURRENT; ?>' class="link">g</a></li>
                </ul>
            </div>
        </li>
        <li>

            Uploaded by <a href="/<?php echo $USERNAME; ?>" class="link"><?php echo $USERNAME; ?></a> On <span style="font-size: 15px;"><?php echo $FULL_TIME; ?></span>
        </li>
        <li><p></p></li>
        <li><div style="overflow: hidden;">
                <input type="button" id="showPhotDetailButton" value="Show Detail" onclick="showImageDetail()"/>
                <input type="button" style="display: none;" id="hidePhotDetailButton" value="Hide Detail" onclick="hideImageDetail()"/>
            </div></li>
        <li><p></p></li>
        <li id="photoDetail" style="height: 0px;transition:height 1s;-webkit-transition:height 1s;-o-transition:height 1s;overflow: hidden;">
            <table style="color:#FFF;background: #000;min-width: 300px;" id="photoDetailTable">
                <?php
                $imagicObject = new Imagick("./uploads/original/$image");


                echo "<tr><td>Image Type</td> <td>" . $imagicObject->getImageMimeType() . "</td></tr>";
                echo "<tr><td>Width</td> <td>" . $imagicObject->getImageGeometry()['width'] . "</td></tr>";
                echo "<tr><td>Height</td> <td>" . $imagicObject->getImageGeometry()['height'] . "</td></tr>";
                echo "<tr><td>Size</td> <td>" . ceil($imagicObject->getImageLength() / 1024) . " KB</td></tr>";



                $imageInfo = $imagicObject->getImageProperties();

                //print_f($imageInfo);
                foreach ($imageInfo as $name => $property) {
                    if ($name == "exif:ApertureValue") {
                        echo "<tr><td>Aperture</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Make") {
                        echo "<tr><td>Company</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Model") {
                        echo "<tr><td>Camera</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:ShutterSpeedValue") {
                        echo "<tr><td>Shutter Speed Value</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:ExposureTime") {
                        echo "<tr><td>Exposure Time</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Software") {
                        echo "<tr><td>Software</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:FocalLength") {
                        echo "<tr><td>Focal Length</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:FNumber") {
                        echo "<tr><td>FNumber</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:Flash") {
                        echo "<tr><td>Flash</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:MaxApertureValue") {
                        echo "<tr><td>Max Aperture Value</td> <td>{$property}</td></tr>";
                    } else if ($name == "exif:ISOSpeedRatings") {
                        echo "<tr><td>ISO Speed Rating</td> <td>{$property}</td></tr>";
                    }
                }
                $imagicObject->clear();
                ?>
            </table>
        </li>
    </ul>
</div>
<div>
    <h2>Related</h2>
</div>
<li>
<?php
$query = "select * from images where userid=(select userid from images where img='{$_IMAGE}') && privacy=0 order by time desc";
$COUNT_QUERY = $query;
$res = QUERY::query("$query limit 6");
while ($result = mysqli_fetch_array($res)) {
    IMAGES::card($result['img'], $result['userid'], $result['time']);
}
?>
</li>
<!--
<div style="overflow: hidden;">
    <ul class="horizontalList">
        <li>
            <img src="/uploads/profile/thumb/<?php echo $USER_IMG; ?>" style="max-width:100px;"/></li>
        <li>
            <ul style="padding-left: 10px;">
                <li>
                    <a href="/<?php echo $USERNAME; ?>" class="link"><?php echo $USERNAME; ?></a>
                </li>
                <li>
                    Photos : <?php echo $PHOTOS; ?>
                </li>
                <li>
                    Albums : <?php echo $ALBUMS; ?>
                </li>
            </ul>
        </li>
    </ul>
</div>
-->