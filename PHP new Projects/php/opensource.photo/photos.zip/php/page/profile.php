<?php

$CURRENT_USER_ID = isset($_SESSION['userid'])?$_SESSION['userid']:-10;
$PROFILE_NAME = $pArray[1];
                    $PROFILE_USERID = QUERY::c("select userid from usersignup where username='{$PROFILE_NAME}'");
                    $PROFILE_IMG = QUERY::c("select img from usersignup where username='{$PROFILE_NAME}'");
                    
                    $PROFILE_COVER = QUERY::c("select cover from usersignup where username='{$PROFILE_NAME}'");
                    
                    ?>
                    <li>
                    <script type="text/javascript">function loadAlbumImage(e){xml=post("/albumimage.php","img="+e+"&width="+screen.width+"&height="+screen.height+"&type=album"),$("#fullImageBoxDully").show(),$("#fullImageBox").show(),$("#fullImageBoxContiner").text(xml.responseText)}
                    </script>
                    <script type="text/javascript">function loadProfileMore(){profilepageno++,xml=post("/php/ajax/loadprofilemore.php","pageno="+profilepageno+"&name=<?php echo $PROFILE_NAME;?>"),$("#loadMore").append(xml.responseText),""==xml.responseText&&($("#loadMore").append("<div class='loadNoMore'>No More Photos Available.</div>"),$("#moreProfilePageButton").hide())}profilepageno=1;
                    window.addEventListener("load",function(){document.body.isScrolled=false;$(".profileHeader").css("height:"+(screen.availHeight-55-55)+"px");window.scrollBy(0,55+screen.availHeight/2);});
                    window.addEventListener("scroll",function(){
                        if(document.body.scrollTop>screen.availHeight-110 && !document.body.isScrolled){
                            $(".topShortHeader").show();
                            setTimeout(function(){
                            $(".topShortHeader").css("opacity:1;");
                            $(".topShortHeaderContent").css("left:10px;");
                        },10);
                            document.body.isScrolled=true;
                        }else  if(document.body.scrollTop<screen.availHeight-110){
                            $(".topShortHeader").hide();
                            setTimeout(function(){
                            $(".topShortHeader").css("opacity:0;");
                            $(".topShortHeaderContent").css("left:-50px;");
                        },10);
                            document.body.isScrolled=false;
                        }
                    });
                    </script>
                    <div class="profile">
                        <ul>
                            <li class="profileHeader" style="background-image: url(/uploads/original/<?php echo $PROFILE_COVER;?>);
    height: 350px;
    background-size: cover;
    background-origin: content-box;
    background-position: inherit;
    position: relative;
        margin: 0px;
        background-attachment: fixed;">
                                <ul class="horizontalList" style="    position: absolute;
    left: 0px;
    bottom: 0px;
    overflow: hidden;">
                                    <li>
                                        <ul class="verticalList">
                                            <li class="hoverProfilePic">
                                                <img src="/uploads/profile/thumb/<?php echo $PROFILE_IMG; ?>" style="border: 1px solid #FFF;" alt='images' width="100" height="100"/>
                                                <?php if($PROFILE_USERID==@$_SESSION['userid']){?>
                                                <ul class="hoverHiddenProfilePic">
                                                    <li style="width: 100%;
    height: 100%;
    vertical-align: middle;
    background-color: rgba(255,255,255,0.6);
    color: #FFF;
    text-align: center;"><a href="/<?php echo $PROFILE_NAME; ?>/upload" class="link"><img src='/img/profile_hover.png' style="max-width: 100%;max-height: 100%;"/></a></li>
                                                </ul>
                                                <?php } ?>
                                                
                                            </li>
                         
                                        </ul>
                                    </li>
                                    <li>
                                        <ul style="font-weight: bold;">
                                            <li>
                                                <a href="/<?php echo $PROFILE_NAME; ?>" class="link"><?php echo ucfirst($PROFILE_NAME); ?></a>
                                            </li>
                                            <li>Albums : <?php echo QUERY::c("select count(*) from album where userid=$PROFILE_USERID"); ?></li>
                                            <li>Photos : <?php echo QUERY::c("select count(*) from images where userid=$PROFILE_USERID"); ?></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            
                            <li class="profileHeaderShort topShortHeader" style="display:none;background-image: url(/uploads/original/<?php echo $PROFILE_COVER;?>);height: 350px;background-size: cover;background-origin: content-box;background-position: inherit;
        margin: 0px;">
                                <ul class="horizontalList topShortHeaderContent" style="color:#FFF;position: absolute;left: 0px;bottom: 0px;overflow: hidden;" class="">
                                    <li>
                                        <ul class="verticalList ">
                                            <li class="hoverProfilePic">
                                                <img src="/uploads/profile/thumb/<?php echo $PROFILE_IMG; ?>" style="border: 1px solid #FFF;" alt='images' width="50" height="50"/>
                                                <?php if($PROFILE_USERID==@$_SESSION['userid']){?>
                                                <ul class="hoverHiddenProfilePic">
                                                    <li style="width: 100%;
    height: 100%;
    vertical-align: middle;
    background-color: rgba(255,255,255,0.6);
    color: #FFF;
    text-align: center;"><a href="/<?php echo $PROFILE_NAME; ?>/upload" class="link"><img src='/img/profile_hover.png' style="max-width: 100%;max-height: 100%;"/></a></li>
                                                </ul>
                                                <?php } ?>
                                                
                                            </li>
                         
                                        </ul>
                                    </li>
                                    <li>
                                        <ul style="font-weight: bold;">
                                            <li>
                                                <a href="/<?php echo $PROFILE_NAME; ?>" class="link"><?php echo ucfirst($PROFILE_NAME); ?></a>
                                            </li>
                                            <li>Albums : <?php echo QUERY::c("select count(*) from album where userid=$PROFILE_USERID"); ?></li>
                                            <li>Photos : <?php echo QUERY::c("select count(*) from images where userid=$PROFILE_USERID"); ?></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><p></p></li>
                            <li class="profileMain" style="text-align: center;">
                                <ul class="horizontalList profileMenu" style="display: inline-block;">
                                    <li class="profileMenuphotos"><a href="/<?php echo $PROFILE_NAME; ?>/" class="link">Photos</a></li>
                                    <li class="profileMenualbums"><a href="/<?php echo $PROFILE_NAME; ?>/albums" class="link">Albums</a></li>
                                    <li class="profileMenulikes"><a href="/<?php echo $PROFILE_NAME; ?>/likes" class="link">Likes</a></li>
                                    <li class="profileMenufavourites"><a href="/<?php echo $PROFILE_NAME; ?>/favourites" class="link">Favourites</a></li> 
                                </ul>
                            </li>
                            <li><p></p></li>
                            <li class="overflow profileMainContent" id="loadMore">
    <?php
    $PROFILE_OP = (isset($pArray[2])) ? ($pArray[2]) : "";
    if ($PROFILE_OP != "photos" && $PROFILE_OP != "albums" && $PROFILE_OP != "upload" && $PROFILE_OP != "likes" && $PROFILE_OP != "favourites") {
        $PROFILE_OP = "photos";
    }
    echo "<script type='text/javascript'>$('.profileMenu$PROFILE_OP').css('border-bottom:#111 solid 3px;');</script>";
    if ($PROFILE_OP == "photos") {
        $PAGE_NO = 1;
        if (isset($pArray['3'])) {
            if (is_numeric($pArray['3'])) {
                $PAGE_NO = $pArray['3'];
            }
        }
        $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
        $query = "select * from images where (privacy=0 or ($PROFILE_USERID=$CURRENT_USER_ID)) && enable=0 && userid=$PROFILE_USERID order by time desc";
        $COUNT_QUERY = $query;
        $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
        while ($result = mysqli_fetch_array($res)) {
            IMAGES::card($result['img'], $result['userid'], $result['time']);
        }
        $TOTAL_POST = QUERY::c("select count(*) as count from ($COUNT_QUERY) as dummy");
        if($TOTAL_POST=="0"){
            echo "<li>No Photos.</li>";
        }
        else if($TOTAL_POST>$POST_PER_PAGE){
        echo "<li>";
                    echo "<div onclick='loadProfileMore()' id='moreProfilePageButton' class='center'>"
                    . "<span class='moreBox center'>Load more</span>"
                            . "</div>";
                    echo "</li>";
                    
        }
    } else if ($PROFILE_OP == "albums") {
        $ALUBUM = (isset($pArray['3'])) ? $pArray['3'] : "";
        if (QUERY::c("select count(*) from album where userid=$PROFILE_USERID and album='{$ALUBUM}'") == "1") {
            $res = QUERY::query("select * from album where userid=$PROFILE_USERID and album='{$ALUBUM}'");
            while ($result = mysqli_fetch_array($res)) {

                IMAGES::singleAlbum($result['albumid']);
            }
        } else {
            $res = QUERY::query("select * from album where userid=$PROFILE_USERID order by time desc"); 
            while ($result = mysqli_fetch_array($res)) {
                IMAGES::album($result['albumid']);
            }
        }
    }else if ($PROFILE_OP == "likes") {
        $PAGE_NO = 1;
        if (isset($pArray['3'])) {
            if (is_numeric($pArray['3'])) {
                $PAGE_NO = $pArray['3'];
            }
        }
        $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
        $query = "select * from images where imgid IN (select imgid from imagelike where userid=$PROFILE_USERID) order by time desc";
        $COUNT_QUERY = $query;
        $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
        while ($result = mysqli_fetch_array($res)) {
            IMAGES::card($result['img'], $result['userid'], $result['time']);
        }
        $TOTAL_POST = QUERY::c("select count(*) as count from ($COUNT_QUERY) as dummy");
        if($TOTAL_POST=="0"){
            echo "<li style='text-align: center;color:#777;'><h3>You Have Not Liked  Any Photo.<h3><p></p></li>";
        }
        else if($TOTAL_POST>$POST_PER_PAGE){
        echo "<li>";
                    echo "<div onclick='loadProfileMoreLike()' id='moreProfilePageButton' class='center'>"
                    . "<span class='moreBox center'>Load more</span>"
                            . "</div>";
                    echo "</li>";
                    
        }
    }else if ($PROFILE_OP == "favourites") {
        $PAGE_NO = 1;
        if (isset($pArray['3'])) {
            if (is_numeric($pArray['3'])) {
                $PAGE_NO = $pArray['3'];
            }
        }
        $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
        $query = "select * from images where imgid IN (select imgid from imagefav where userid=$PROFILE_USERID) order by time desc";
        $COUNT_QUERY = $query;
        $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
        while ($result = mysqli_fetch_array($res)) {
            IMAGES::card($result['img'], $result['userid'], $result['time']);
        }
        $TOTAL_POST = QUERY::c("select count(*) as count from ($COUNT_QUERY) as dummy");
        if($TOTAL_POST=="0"){
            echo "<li style='text-align: center;color:#777;'><h3>You Have Not Added Any Photo To Your Favourites.<h3><p></p></li>";
        }
        else if($TOTAL_POST>$POST_PER_PAGE){
        echo "<li>";
                    echo "<div onclick='loadProfileMoreFav()' id='moreProfilePageButton' class='center'>"
                    . "<span class='moreBox center'>Load more</span>"
                            . "</div>";
                    echo "</li>";
                    
        }
    } else if ($PROFILE_OP == "upload" && strtolower ($PROFILE_NAME) == @$_SESSION['username']) {
        ?>
                                    <form method="post"  action="/uploadprofile.php" enctype="multipart/form-data">
                                        <div class="upload">
                                            <div><h3>Update Profile Photo</h3></div>
                                            <div><input type="file" name="file" id="uploadphoto" onchange="previewImage()"/></div>
                                            <p></p>
                                            <div>
                                                <h4>Preview </h4>
                                                <p></p>
                                                <div id="addPreviewImage">

                                                </div>
                                            </div>
                                            <p></p>
                                            <div><input type="submit" value="upload" class="input"/></div>
                                        </div>
                                    </form>
                                    <script type="text/javascript">function previewImage(){var e=document.getElementById("uploadphoto");if(e.files&&e.files[0]){var r,o,t,a=new FileReader;a.onload=function(a){var i=a.target.result,d=document.createElement("img");d.src=i,r=d.width,o=d.height,t=e.files[0].size,$("#addPreviewImage").text("<img src='"+d.src+"' class='previewImg'/>"),$("#errorPhotoUpload").text("")},a.onerror=function(e){console.error("File could not be read! Code "+e.target.error.code)},a.readAsDataURL(e.files[0])}}
                                    </script>
        <?php
    }
    ?>
                            </li>
                        </ul>
                    </div>
                    </li>