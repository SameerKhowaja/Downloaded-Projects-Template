<?php
parse_str(@$_SERVER['REDIRECT_QUERY_STRING'], $output);
$searchFor = @$output['searchfor'];
        
        ?>
<div style="padding:10px 0px;">
    <input type="text" id="searchText" style="    width: 60%;
    min-width: 400px;
    padding: 5px;
    width: 88%;
    padding: 1%;
    font-weight: bold;
    margin: 0px;
    outline: none;
    border: none;
    border-bottom: 2px solid #777;
    margin-bottom: 10px;
    font-size: 1.5em;" onkeyup="instantSearch()" placeholder="search for images" value="<?php echo $searchFor;?>"/>
    <input type="button" value="Search" onclick="search()" style="    width: 8%;
    margin: 0;
    padding: 0% 1%;
    padding-top: 10px;
    padding-bottom: 10px;
    font-size: 1.2em;"/>
</div>
<div id="addSearchResult">

</div>
<script>
    function search() {
        searchString = $("#searchText").val();
        window.location.href = "/search/?searchfor=" + searchString;
    }
    function instantSearch()
    {
        if(event.keyCode==13)
            search();
        
    }
</script>
<ul style="width:100%;overflow: hidden;" class="mainContent">
    <li id="loadData" style="width:100%;">
        
        <?php
        $CURRENT_USER_ID = isset($_SESSION['userid'])?$_SESSION['userid']:-10;
        
        if ($searchFor != "") {
            $searchFor = mysqli_escape_string(QUERY::$con, $searchFor);
            $PAGE_NO = 1;
            $START_POST = $POST_PER_PAGE * ($PAGE_NO - 1);
            $query = "select * from images where (privacy=0 or userid=$CURRENT_USER_ID) and title like '%$searchFor%' order by time desc";
            $COUNT_QUERY = $query;
            $msc = microtime(true);
            $res = QUERY::query("$query limit $START_POST,$POST_PER_PAGE");
            $msc = microtime(true) - $msc;
            echo "<div style='color:#999;'>" . mysqli_num_rows($res) . " results found in " . ($msc * 1000) . " seconds" . "</div>";
            while ($result = mysqli_fetch_array($res)) {
                IMAGES::card($result['img'], $result['userid'], $result['time']);
            }
            if (mysqli_num_rows($res) == 0) {
                echo "<div>No Result Found.</div>";
            } else if (mysqli_num_rows($res) < $POST_PER_PAGE) {
                echo "<div style='clear:both'>No More Result.</div>";
            }
        }  else {
            echo "<h2 style='color:#999;'>Search Images</h2>";
        }
        ?>
        
    </li>
</ul>