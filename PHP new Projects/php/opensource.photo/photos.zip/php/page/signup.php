<li>
                    <div class="signupBox">
                        <div class="signupBoxContainer">
                            <div class="signupTitle">   <img src="/img/icon.png" width="100" height="40" alt="home"/></div>
                            <div class="error" id="signuperror"></div>
                            <div>   Username   <span id="errorusername" class="error"></span></div>
                            <div><input type="text" placeholder="Enter Your Username" class="input" id="signUpName"/></div>
                            <div>   Password   <span id="errorSignUpPassword" class="error"></span></div>
                            <div><input type="password" placeholder="Enter Your Password" class="input" id="signUpPass"/></div>
                            <div>   Confirm password   <span id="errorSignUpPassword" class="error"></span></div>
                            <div><input type="password" placeholder="Enter Password Again" class="input" id="signUpConfirm"/></div>
                            <div>   Captcha  <span id="errorSignUpPassword" class="error"></span></div>
                            <?php echo CAPTCHA::get("signup"); ?>
                            <div><input type="button" value="Signup" class="input" onclick="signup()"/></div>
                            <div><div><a href="/login" class="link">Log in?</a></div></div>
                        </div>
                    </div>
                    <script type="text/javascript">function changecapitchasignup(){if(xmlhttp=post("/php/db/signup.php","username=1&pass=1&capitcha="+capitcha+0x9475e6d3c2c),text=xmlhttp.responseText,text=text.substr(0,5),"CAPIT"==text){var t=xmlhttp.responseText;t=t.substring(5,6),$("#capitchacontent").text(t),left=100*Math.random()%60,$("#capitchacontent").css("left",0==left?1:left+"px")}}function signup(){var t=$("#signUpName").val(),e=$("#signUpPass").val(),r=$("#signUpConfirm").val(),s=$("#capitcha").val(),a=$("#capitcha").attr("data-token"),n="";if(e!=r?($("#signuperror").text("Password and Confirm password did not match"),n="error"):$("#signuperror").text(""),""==t?($("#errorusername").text("this field is required"),n="error"):$("#errorusername").text(""),""==e&&""==r&&($("#errorSignUpPassword").text("this field is required"),n="error"),""==e&&($("#errorSignUpPassword").text(""),n="error"),""==s&&($("#errorcapitcha").text("this is required"),n="false"),""==n)if(xmlhttp=post("/php/db/signup.php","username="+t+"&pass="+e+"&capitcha="+s+"&token="+a),text=xmlhttp.responseText,text=text.substr(0,5),"NOTOK"==text)$("#signuperror").text("sorry!!! username already exits");else if("ECAPI"==text){var i=xmlhttp.responseText;i=i.substring(5,6),$("#capitchacontent").text(i),$("#errorcapitcha").text("care to try agin!!!")}else"IUSER"==text?$("#signuperror").text("Username contain alphbates numbers & special character(_)"):"IPASS"==text?$("#signuperror").text("Password contain alphbates numbers & special character(_,?,@)"):(text="<span class='signupSuccess'>you have successfully created your account. Now you can log in</span>",$(".signupBoxContainer").text(text))}
                    </script>
                    </li>