<li>
    <form method="post"  action="/upload.php" enctype="multipart/form-data">
        <div class="none" id="uploadSuccessMsg">
            <h1>Uploaded Successfully.</h1>
            <div><input type="button" class="input" value="upload another photo" onclick="showUpload()"/></div>
        </div>
        <div class="upload">
            <h3 id="status"></h3>
            <div><h3>Upload New Photo</h3></div>
            <div id="uploadInputFileContainer" class="input">
                <div style="position:relative;">
                    <div class="addImage">
                        Add Image <br/>
                        Or<br/>
                        Drop Image
                    </div>
                    <input type="file" class="uploadImageInput" name="file" id="uploadphoto"  onchange="previewImage()"/>

                </div>
            </div>
            <p></p>
            <div><progress class="input none" id="progressBar" value="0" max="100"></progress></div>
            <p></p>
            <div><span id="loaded_n_total"></span></div>
            <p></p>
            <div><input type="text" class="input" placeholder="Enter Title" id="photoTitle"/></div>
            <p></p>
            <div>
                Album Name
            </div>
            <div class="albumName" id="albumName">
                <div><input type="text" list="preAlbumName" id="albumNameval" name="albumName" class="input" placeholder="Enter Your Album Name" value="self"/></div>
                <div><input type="button" value="Create New Album" class="input" onclick="showNewAlbumOption()"/></div>
                <div><input  type="text" class="none" id="albumType" class="input" name="albumType" value="0"/></div>
            </div>
            <datalist id="preAlbumName">
                <option value="self">                          
                    <?php
                    $userid = $_SESSION['userid'];
                    $res = QUERY::query("select album from album where userid=$userid");
                    while ($result = mysqli_fetch_array($res)) {
                        $album = $result['album'];
                        if ($album != "self")
                            echo "<option value='" . $album . "'>";
                    }
                    ?>
            </datalist>
            <div class="none" id="newAlbumName">
                <div><input type="text" name="newAlbumName" id="newAlbumNameval" class="input" placeholder="Enter New Album Name"/></div>
                <div><input type="button" value="back" class="input" onclick="showOldAlbum()"/></div>
            </div>
            <script type="text/javascript">function showNewAlbumOption() {
                    $("#albumName").hide(), $("#newAlbumName").show(), $("#albumType").val("1")
                }
                function showOldAlbum() {
                    $("#albumName").show(), $("#newAlbumName").hide(), $("#albumType").val("0")
                }
                var ajax;
                function uploadFile() {
                    var file = _("uploadphoto").files[0];
                    // alert(file.name+" | "+file.size+" | "+file.type);
                    if (file.type == undefined || file.size == 0) {
                        return;
                    }
                    $("#progressBar").show();
                    $("#startUploadButton").hide();
                    $("#stopUploadButton").show();
                    var formdata = new FormData();
                    formdata.append("file", file);
                    formdata.append("albumType", $("#albumType").val());
                    formdata.append("newAlbumName", $("#newAlbumNameval").val());
                    formdata.append("albumName", $("#albumNameval").val());
                    formdata.append("title", $("#photoTitle").val());
                    formdata.append("privacy", $("#privacy").val());

                    ajax = new XMLHttpRequest();
                    ajax.upload.addEventListener("progress", progressHandler, false);
                    ajax.addEventListener("load", completeHandler, false);
                    ajax.addEventListener("error", errorHandler, false);
                    ajax.addEventListener("abort", abortHandler, false);
                    ajax.open("POST", "/upload.php");
                    ajax.send(formdata);
                }
                function stopUploading() {
                    ajax.abort();
                }
                function resetForm() {
                    $("#progressBar").hide();
                    $("#startUploadButton").show();
                    $("#stopUploadButton").hide();
                    _("progressBar").value = 0;
                    $("#addPreviewImage").text("");
                    $(".upload").show();
                    $("#uploadSuccessMsg").hide();
                    $("#uploadInputFileContainer").text($("#uploadInputFileContainer").text());
                    $("#progressHeaderbar").css("width", "0px");
                }
                function progressHandler(event) {

                    //_("loaded_n_total").innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
                    var percent = (event.loaded / event.total) * 100;
                    $("#progressHeaderbar").css("width", (screen.width * percent * 0.01) + "px");
                    _("progressBar").value = Math.round(percent);
                    _("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
                }
                function completeHandler(event) {
                    //_("status").innerHTML = event.target.responseText;
                    _("status").innerHTML = "";
                    $(".upload").hide();
                    $("#uploadSuccessMsg").show();
                    _("progressBar").value = 0;
                    _("loaded_n_total").innerHTML = "";
                    $("#startUploadButton").show();
                    $("#stopUploadButton").hide();
                    console.log(ajax.responseText);
                    $("#progressHeaderbar").css("width", "0px");
                }
                function errorHandler(event) {
                    _("status").innerHTML = "Upload Failed";
                    resetForm();
                }
                function abortHandler(event) {
                    _("status").innerHTML = "Upload Aborted";
                    resetForm();
                }
                function showUpload(event) {
                    resetForm();
                    _("status").innerHTML = "";
                }
            </script>
            <div>
                <h4>Privacy</h4>
                <p></p>
                <div>
                    <select id="privacy" name="privacy" style="width: 90%;padding: 1%;">
                        <option>Public</option>
                        <option>Private</option>
                    </select>
                </div>
            </div>
            <div>
                <h4>Preview </h4>
                <p></p>
                <div id="addPreviewImage">

                </div>
            </div>
            <p></p>
            <div><input type="button" onclick="uploadFile()" value="upload" class="input" id="startUploadButton"/></div>
            <div><input type="button" onclick="stopUploading()" value="Cancle upload" class="input none" id="stopUploadButton"/></div>
        </div>
    </form>
    <script type="text/javascript">
        function previewImage() {
            var e = document.getElementById("uploadphoto");
            if (e.files && e.files[0]) {
                $("#addPreviewImage").text("");
                for (j = 0; j < e.files.length; j++) {
                    var tmptitle = e.files[j].name ;
                    tmptitle = tmptitle.split(".").shift();
                    tmptitle = tmptitle.replace(/[^a-zA-Z0-9]/g, ' ');
                    $("#photoTitle").val(tmptitle);
                    var r, o, t, a = new FileReader;
                    a.onload = function(a) {
                        var i = a.target.result;
                        d = document.createElement("img");
                        d.src = i;
                        r = d.width;
                        o = d.height;
                        t = e.files[0].size;
                        $("#addPreviewImage").append("<img src='" + d.src + "' class='previewImg'/>");
                       // $("#addPreviewImage").append("<div style='background-image:url(" + d.src + ");min-height: 200px;background-repeat: no-repeat;background-size: cover;width: 31.33%;' class='previewImg'></div>");
                        $("#errorPhotoUpload").text("");

                    }, a.onerror = function(e) {
                        console.error("File could not be read! Code " + e.target.error.code)
                    }, a.readAsDataURL(e.files[j])
                }
            }
        }

    </script>
</li>