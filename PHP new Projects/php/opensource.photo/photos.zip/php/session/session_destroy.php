<?php include "session_start.php";?>
<?php
session_destroy();
?>