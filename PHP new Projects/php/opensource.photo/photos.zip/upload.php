<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set('max_execution_time', 0);
include "php/class/query.php";
include "php/session/session_start.php";

$IMAGICK_LOADED = false;

if (extension_loaded("imagick")) {
    $IMAGICK_LOADED = true;
}

if (!isset($_SESSION['userid'])) {
    header("Location: /login");
    exit;
}
$userid = $_SESSION['userid'];
if (!isset($_FILES["file"]["name"])) {
    header("Location: /");
    exit;
}
//$_POST=array_map('trim',$_POST);
$NAME = $_FILES["file"]["name"];
/*
  function LoadJpeg($imgname) {
  $imgArray = explode(".", $imgname);
  $type = end($imgArray);

  if ($type == "png") {
  $im = @imagecreatefrompng($imgname);

  } else if ($type == "jpg" || $type == "jpeg") {
  $im = @imagecreatefromjpeg($imgname);
  } else if ($type == "gif") {
  $im = @imagecreatefromgif($imgname);
  }
  if (!$im) {
    $im = @imagecreatefrompng("http://initedit.com/img/nfi.png");
  }
  return $im;
  }
 */
$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
$extension = strtolower($extension);
$uploadpicname = "picture." . $temp[count($temp) - 1];
if ((($_FILES["file"]["type"] == "image/gif") || ($_FILES["file"]["type"] == "image/jpeg") || ($_FILES["file"]["type"] == "image/JPEG") || ($_FILES["file"]["type"] == "image/jpg") || ($_FILES["file"]["type"] == "image/JPG") || ($_FILES["file"]["type"] == "image/pjpeg") || ($_FILES["file"]["type"] == "image/x-png") || ($_FILES["file"]["type"] == "image/png")) && ($_FILES["file"]["size"] <= 20 * 1024 * 1024) && in_array($extension, $allowedExts)) {
    if ($_FILES["file"]["error"] > 0) {
        echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    } else {
        echo "Upload: " . $_FILES["file"]["name"] . "<br>";
        echo "Type: " . $_FILES["file"]["type"] . "<br>";
        echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
        echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br>";
        $quality = 100;
        if (($_FILES["file"]["size"] / 1024) > 1000) {
            $quality = 50;
        }
        $target_dir = "uploads/original/";
        $rand_number = md5(time() . rand() * 1000000);

        $target_file = $target_dir . $rand_number . "." . $extension;
        move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
        echo "Stored in: " . $target_file;
        $imgname = "./" . $target_file;

        //$img = LoadJpeg($imgname);


        list($width, $height, $type, $attr) = getimagesize("./uploads/original/" . $rand_number . "." . $extension);
        $newWidth = $width;
        $newHeight = $height;
        $fact = 0.9;
        while ($newHeight > 300 || $newWidth > 300) {
            $newWidth = $newWidth * $fact;
            $newHeight = $newHeight * $fact;
        }
        if ($IMAGICK_LOADED) {
            $originalImagick = new Imagick("./uploads/original/" . $rand_number . "." . $extension);
            $originalImagick->thumbnailimage($newWidth, $newHeight, true);
            $originalImagick->setImageCompressionQuality(0);
            $originalImagick->writeImage("./uploads/thumb/" . $rand_number . "." . $extension);
            //$img = LoadJpeg($imgname);
            $originalImagick->clear();
//Resize Original Image
            list($width, $height, $type, $attr) = getimagesize("./uploads/original/" . $rand_number . "." . $extension);
            $originalImagick = new Imagick("./uploads/original/" . $rand_number . "." . $extension);
            if ($width > 2048) {
                $originalImagick->scaleImage(2048, 0);
            }
            $originalImagick->writeImage("./uploads/original/" . $rand_number . "." . $extension);
            $originalImagick->clear();
            //compressed images
            $originalImagick = new Imagick("./uploads/original/" . $rand_number . "." . $extension);
            if (strtolower($originalImagick->getImageFormat()) == "png") {
                $originalImagick->setimagedepth(4);
            }
            $originalImagick->setImageCompressionQuality(0);
            $originalImagick->writeImage("./uploads/compressed/" . $rand_number . "." . $extension);
            if (strtolower($originalImagick->getImageFormat()) == "jpg" || strtolower($originalImagick->getImageFormat()) == "jpeg") {
                $image = imagecreatefromjpeg("./uploads/compressed/" . $rand_number . "." . $extension);
                $destination = "./uploads/compressed/" . $rand_number . "." . $extension;
                $quality = 50;
                imagejpeg($image, $destination, $quality);
            }
            $originalImagick->clear();
        }else{
                copy("./uploads/original/" . $rand_number . "." . $extension,"./uploads/thumb/" . $rand_number . "." . $extension);
                copy("./uploads/original/" . $rand_number . "." . $extension,"./uploads/compressed/" . $rand_number . "." . $extension);



        }


        /*
          $dst = imagecreatetruecolor($newWidth, $newHeight);

          $black = imagecolorallocate($dst, 0, 0, 0);
          imagecolortransparent($dst, $black);
          imagecopyresampled($dst, $img, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
         */

        /*
          if ($extension == "jpg" || $extension == "jpeg") {
          imagejpeg($img, "uploads/small/" . $rand_number . "." . $extension, $quality);
          } else if ($extension == "png") {
          imagejpeg($img, "uploads/small/" . $rand_number . "." . $extension, $quality);
          } else if ($extension == "gif") {
          imagejpeg($img, "uploads/small/" . $rand_number . "." . $extension, $quality);
          }

          // $quality=100;
          if ($extension == "jpg" || $extension == "jpeg") {
          imagejpeg($dst, "uploads/thumb/" . $rand_number . "." . $extension, $quality);
          } else if ($extension == "png") {
          imagejpeg($dst, "uploads/thumb/" . $rand_number . "." . $extension, $quality);
          } else if ($extension == "gif") {
          imagegif($dst, "uploads/thumb/" . $rand_number . "." . $extension, $quality);
          }
         */
        if (QUERY::c("select count(*)  from album where userid=$userid and album='self'") == "0") {
            QUERY::query("insert into album(userid,album) values($userid,'self')");
        }

        $imageName = $rand_number . "." . $extension;
        $albumType = $_POST['albumType'];
        if ($albumType == "0") {
            $album = @$_POST['albumName'];
            $album = mysqli_escape_string(QUERY::$con, $album);
            if (QUERY::c("select count(*) from album where album='{$album}'") != "1") {
                $album = "self";
            }
            echo mysqli_error(QUERY::$con);
        } else {
            $album = $_POST['newAlbumName'];
            $album = mysqli_escape_string(QUERY::$con, $album);
            if ($album != "") {
                if (QUERY::c("select count(*) from album where userid=$userid and album='{$album}'") == "0") {
                    QUERY::query("insert into album(userid,album) values($userid,'{$album}')");
                }
            }
        }

        $title = ($_POST['title'] != "") ? $_POST['title'] : $NAME;
        $privacy = ($_POST['privacy'] == "Public") ? 0 : 1;
        $album = mysqli_escape_string(QUERY::$con, $album);
        $title = mysqli_escape_string(QUERY::$con, $title);

        $albumid = QUERY::c("select albumid from album where userid=$userid and album='{$album}'");
        QUERY::query("insert into images(img,userid,albumid,title,name,privacy) values ('{$imageName}',$userid,$albumid,'{$title}','{$NAME}',$privacy)");

    }
} else {
    echo "Invalid file";
}
?>